## Deprecations
- Event: `Mautic\CoreBundle\CoreEvents::ON_FORM_TYPE_BUILD`
- Whole class: `Mautic\CoreBundle\Event\CustomFormEvent`
- Service: `'mautic.form.extension.custom'` which is class `Mautic\CoreBundle\Form\Extension\CustomFormExtension`
