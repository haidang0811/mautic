<?php

namespace Mautic\CategoryBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MauticCategoryBundle extends Bundle
{
}
