<?php

namespace Mautic\CampaignBundle\Membership\Exception;

use Mautic\CoreBundle\Exception\FlattenableException;

class ContactCannotBeAddedToCampaignException extends FlattenableException
{
}
