<?php

namespace Mautic\CampaignBundle;

use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\HttpKernel\Bundle\Bundle;

class MauticCampaignBundle extends Bundle
{
    public function build(ContainerBuilder $container): void
    {
    }
}
