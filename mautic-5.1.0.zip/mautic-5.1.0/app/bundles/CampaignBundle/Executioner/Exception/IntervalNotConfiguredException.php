<?php

declare(strict_types=1);

namespace Mautic\CampaignBundle\Executioner\Exception;

class IntervalNotConfiguredException extends \Exception
{
}
