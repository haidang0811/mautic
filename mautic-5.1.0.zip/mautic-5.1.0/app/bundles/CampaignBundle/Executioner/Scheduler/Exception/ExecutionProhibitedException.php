<?php

namespace Mautic\CampaignBundle\Executioner\Scheduler\Exception;

/**
 * @deprecated since Mautic 5.0, to be removed in 6.0 with no replacement.
 */
class ExecutionProhibitedException extends \Exception
{
}
