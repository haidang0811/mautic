<?php

namespace Mautic\ApiBundle\Security\OAuth2\Firewall;

class OAuthListener extends \FOS\OAuthServerBundle\Security\Firewall\OAuthListener
{
}
