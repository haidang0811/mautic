<?php

namespace Mautic\AssetBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MauticAssetBundle extends Bundle
{
}
