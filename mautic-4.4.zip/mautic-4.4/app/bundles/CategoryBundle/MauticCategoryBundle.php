<?php

namespace Mautic\CategoryBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

/**
 * Class MauticCategoryBundle.
 */
class MauticCategoryBundle extends Bundle
{
}
