<?php

namespace Mautic\CalendarBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

/**
 * Class MauticCalendarBundle.
 */
class MauticCalendarBundle extends Bundle
{
}
