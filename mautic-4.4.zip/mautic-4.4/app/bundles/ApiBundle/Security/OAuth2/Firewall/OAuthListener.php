<?php

namespace Mautic\ApiBundle\Security\OAuth2\Firewall;

/**
 * Class OAuthListener.
 */
class OAuthListener extends \FOS\OAuthServerBundle\Security\Firewall\OAuthListener
{
}
