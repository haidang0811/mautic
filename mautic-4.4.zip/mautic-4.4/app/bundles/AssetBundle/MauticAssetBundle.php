<?php

namespace Mautic\AssetBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

/**
 * Class MauticAssetBundle.
 */
class MauticAssetBundle extends Bundle
{
}
