<?php

namespace Mautic\CampaignBundle\Executioner\Scheduler\Exception;

class ExecutionProhibitedException extends \Exception
{
}
