<?php

namespace Mautic\CampaignBundle\Executioner\Exception;

class NoContactsFoundException extends \Exception
{
}
