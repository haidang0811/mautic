<?php

namespace Mautic\CampaignBundle\Executioner\Exception;

class DecisionNotApplicableException extends \Exception
{
}
