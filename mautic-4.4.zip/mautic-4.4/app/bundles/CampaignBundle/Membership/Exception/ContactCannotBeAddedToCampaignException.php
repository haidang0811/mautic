<?php

namespace Mautic\CampaignBundle\Membership\Exception;

class ContactCannotBeAddedToCampaignException extends \Exception
{
}
